# GENERATED VERSION FILE
# TIME: Mon Mar 16 22:22:29 2020

__version__ = '1.1.0+01ed853'
short_version = '1.1.0'
